// ==UserScript==
// @icon           http://baidu.com/favicon.ico
// @name           百度百科 无水印图片查看
// @namespace      http://weibo.com/liangxiafengge
// @version        1.2.3.2
// @description    查看百科最新版本、历史版本无水印图片，历史图册页面进入的图片暂时不支持。
// @match          http://baike.baidu.com/picture/*
// @match          http://baike.baidu.com/historypic/*
// @match          https://baike.baidu.com/historypic/*
// @match          http://baike.baidu.com/pic/*
// @match          https://baike.baidu.com/pic/*
// @match          http://baike.baidu.com/picview/history/*
// @run-at         document-end
// ==/UserScript==

var imgFrameId   = 'imgPicture';                               //图片所在元素的id
var clearImgHost = 'imgsrc.baidu.com';                         //无水印图片的host
var imgId        = window.location.href.split('pic=')[1];
//获取元素
var imgPicture   = document.getElementById( imgFrameId );
var imgButton    = document.getElementsByClassName('tool-button origin')[0];
document.getElementsByClassName('tool-button info')[0].style.display = 'none';

var check        = setInterval( changeImg , 10 );             //定时执行，以替换掉

// 按下左键，重新替换 0 left ; 1 middle; 2 right
document.onmouseup= function (e){
    var value=(window.e||e).button;
    if(value===0)
        check=setInterval( changeImg , 10);
}
// 鼠标滚动，重新替换
window.onmousewheel=document.onmousewheel=function (){
   check=setInterval( changeImg , 10);
}
//按动了上下方向键，38=上键，37=左键，40=下键，39=右键
document.onkeydown=function(event){
    var e = event || window.event || arguments.callee.caller.arguments[0];
    if(e && e.keyCode==38 || e && e.keyCode==40){//上,下
        check=setInterval( changeImg , 10);
    }
};

//替换有水印的图片，替换“原图”中的链接
function changeImg()
{
    if (  (imgPicture.src.indexOf('sign=')!=-1 )   )//|| ( isFirst === 1 )
    {
        imgId=window.location.href.split('pic=')[1];
        imgButton.href = imgPicture.src = 'http://imgsrc.baidu.com/baike/pic/item/' + imgId + '.jpg';
        check=window.clearInterval( check );
    }
}

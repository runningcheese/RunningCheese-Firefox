# Regex Analyzer

Imported from: <https://github.com/foo123/RegexAnalyzer>
Author: Nikos M.

## Changes to the imported library

date: 2022-11-17
commit: d51b7e082b73db745a1f8321e65b086902d80d80
github link: <https://github.com/gorhill/uBlock/commit/d51b7e082b73db745a1f8321e65b086902d80d80>

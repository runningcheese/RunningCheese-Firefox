// ==UserScript==
// @name        百度百科 - 将图片改为无水印版本
// @namespace   RainSlide
// @version     1.3.1.5
// @description 本脚本为 百度百科 无水印图片查看 的无 jQuery 版本。原脚本链接：https://greasyfork.org/scripts/16607
// @icon        https://baike.baidu.com/favicon.ico
// @run-at      document-end
// @grant       none

// @match https://baike.baidu.com/pic/*
// @match  http://baike.baidu.com/pic/*
// @match https://baike.baidu.com/picture/*
// @match  http://baike.baidu.com/picture/*
// @match https://baike.baidu.com/historypic/*
// @match  http://baike.baidu.com/historypic/*
// @match https://baike.baidu.com/picview/history/*
// @match  http://baike.baidu.com/picview/history/*
// @match https://bkimg.cdn.bcebos.com/pic/*

// ==/UserScript==

(() => {

// 无水印原图链接前缀（已不再需要）
// const srcPrefix = "https://imgsrc.baidu.com/baike/pic/item/";

// 百度百科图片链接前缀
const srcPrefix = "https://bkimg.cdn.bcebos.com/pic/";

// 图片链接中的水印字符串
const watermarkStr = "/watermark";

// 图片元素
const imgPicture = document.getElementById( 'imgPicture' );

// 脚本会设置 MutationObserver，在脚本运行完毕后，MutationObserver 仍然会存在
// 它会监视 imgPicture 的 src 属性变化，每次变化时执行一次回调函数
// 所以，仅在图片元素及其存在时执行
if (
	imgPicture &&
	imgPicture.src &&
	imgPicture.src.startsWith( srcPrefix )
) {

	// 是否输出调试日志
	const debug = false;

	// 存储当前图片链接
	let currectImgUrl = "";

	// 目标列表 可以较简单地添加要替换的项目
	// 格式：[ 元素, '属性名' ]
	// 不要忘记用英文逗号分隔项目
	const targetMap = new Map([
		// #imgPicture 图片的地址
		[ imgPicture, "src" ],
		// “原图” 按钮指向的链接
		[ document.querySelector( 'a.tool-button.origin' ), "href" ]
	]);

	// 将图片链接替换为无水印版本的函数
	// 在 MutationObserver 的回调函数中被调用
	const replaceImgUrl = () => {

		// 从带水印图片的链接得到无水印原图的链接
		const oldImgUrl = imgPicture.src;
		const newImgUrl = (
			oldImgUrl => oldImgUrl.origin.concat( oldImgUrl.pathname )
		)( new URL(oldImgUrl) );

		// 使用 forEach() 对目标列表进行批量判断与替换
		targetMap.forEach(
			( attr, element ) =>
				// 如果目标元素的属性值不等于 newImgUrl
				element.getAttribute( attr ) !== newImgUrl
				// 便将其替换为 newImgUrl
				&& element.setAttribute( attr, newImgUrl )
		);

		// 替换完成后，将新的无水印原图链接存入 currectImgUrl
		currectImgUrl = newImgUrl;

		if ( debug ) {
			console.debug( "前：" + oldImgUrl );
			console.debug( "后：" + newImgUrl );
		}

	};

	replaceImgUrl();

	new MutationObserver(
		mutationsList => {
			debug && console.debug(mutationsList);
			// 更改后，如果目标元素的属性值不等于 currectImgUrl
			imgPicture.src !== currectImgUrl
			// 执行替换
			&& replaceImgUrl();
		}
	).observe(
		imgPicture, {
			childList: false, // 是否监视直接子节点变化
			subtree: false,   // 如果监视直接子节点变化，是否将监视范围扩展至所有子节点

			attributes: true,
			attributeFilter: [ "src" ], // 要监视的属性名称的数组
			attributeOldValue: false,

			characterData: false,
			characterDataOldValue: false
		}
	);

} else if (
	location.href.startsWith(srcPrefix) &&
	location.search.includes(watermarkStr)
) {
	location.assign(
		location.origin.concat( location.pathname )
	);
};

})();
